  
<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div style="border-radius: 0px;" class="modal-content">
      <div style="background: #212121;border-radius: 0px  " class="text-white modal-header">
        <h5 class="modal-title " id="exampleModalLongTitle">Contact Us</h5>
        <button style="position: absolute; left: 95%; top: -4%" type="button" class="close " data-dismiss="modal" aria-label="Close">
        <img width="25px" src="<?php bloginfo('template_directory'); ?>/img/portfolio/458594.png" alt="">
        </button>
      </div>
      <div class="modal-body">
       <div class="col-auto">
      <label class="sr-only" for="inlineFormInputGroup">Username</label>
      <div style="border-radius: 0px" class="input-group mb-2">
        <div style="border-radius: 0px" class="input-group-prepend">
          <div style="border-radius: 0px" class="text-danger input-group-text"><span class="far fa-user"></span></div>
        </div>
        <input style="border-radius: 0px" type="text" class="form-control" id="inlineFormInputGroup" placeholder="Username">
      </div>
    </div>
	<div class="col-auto">
      <label class="sr-only" for="inlineFormInputGroup">Username</label>
      <div style="border-radius: 0px" class="input-group mb-2">
        <div style="border-radius: 0px" class="input-group-prepend">
          <div style="border-radius: 0px" class="text-danger input-group-text"><span class="fa fa-phone"></span></div>
        </div>
        <input style="border-radius: 0px" type="text" class="form-control" id="inlineFormInputGroup" placeholder="Username">
      </div>
    </div>
		  <div class="col-auto">
      <label class="sr-only" for="inlineFormInputGroup">Username</label>
      <div style="border-radius: 0px" class="input-group mb-2">
        <div style="border-radius: 0px" class="input-group-prepend">
          <div style="border-radius: 0px" class="text-danger input-group-text"><span class="far fa-envelope"></span></div>
        </div>
        <input style="border-radius: 0px" type="text" class="form-control" id="inlineFormInputGroup" placeholder="Username">
      </div>
    </div>
		  <div class="col-auto">
      <label class="sr-only" for="inlineFormInputGroup">Username</label>
      <div style="border-radius: 0px" class="input-group mb-2">
        <div style="border-radius: 0px" class="input-group-prepend">
          <div style="border-radius: 0px" class="text-danger input-group-text"><span class="	fab fa-facebook-messenger"></span></div>
        </div>
		  <textarea style="border-radius: 0px" class="form-control" rows="2" id="comment"></textarea>
        
      </div>
			  <button style="border-radius: 80px; width: auto;" class=" btn btn-danger btn-sm"><center><span class="fa fa-paper-plane"></span> SEND MESSAGE</center></button>
    </div>
	
	
      </div>
   
    </div>
  </div>
</div>


<!-- Footer -->
  <footer class=" text-center">
    <img width="100%" src="<?php bloginfo('template_directory'); ?>/img/portfolio/FOOTER@2x.png" alt="">
  </footer>

  <!-- Copyright Section -->
  

  <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
  <div class="scroll-to-top d-lg-none position-fixed ">
    <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
      <i class="fa fa-chevron-up"></i>
    </a>
  </div>

<?php wp_footer(); ?>

</body>

</html>